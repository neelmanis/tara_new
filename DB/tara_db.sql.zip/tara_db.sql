-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 17, 2016 at 05:43 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tara_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE IF NOT EXISTS `admin_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `contact_name` varchar(255) NOT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `status` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_master`
--

INSERT INTO `admin_master` (`id`, `post_date`, `contact_name`, `email_id`, `password`, `role`, `mobile_no`, `status`) VALUES
(1, '2016-04-20 12:11:07', 'taraadmin', 'neelmani@kwebmaker.com', 'taraadmin@2016', 'Admin', '9619662253', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `post_date`, `modified_date`, `title`, `image`, `status`) VALUES
(1, '2016-05-03 11:17:40', '0000-00-00 00:00:00', 'Banner1', '39257slide_1.jpg', '1'),
(2, '2016-05-03 11:17:54', '0000-00-00 00:00:00', 'Banner 2', '79256slide_2.jpg', '1'),
(3, '2016-05-03 11:18:08', '0000-00-00 00:00:00', 'Banner 3', '15467slide_3.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cid` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `video` varchar(250) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `post_date`, `modified_date`, `name`, `video`, `status`) VALUES
(1, '2016-04-27 15:37:21', '0000-00-00 00:00:00', 'JEWELLERY', '', '1'),
(2, '2016-04-30 13:36:13', '0000-00-00 00:00:00', 'WHAT’S NEW', '', '1'),
(3, '2016-05-04 18:51:35', '2016-05-04 18:51:40', 'SOLITAIRES', '', '1'),
(4, '2016-05-05 10:52:05', '0000-00-00 00:00:00', 'COINS', '', '1'),
(5, '2016-05-05 11:02:12', '0000-00-00 00:00:00', 'COLLECTIONS', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_enquiry`
--

CREATE TABLE IF NOT EXISTS `customer_enquiry` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customer_enquiry`
--

INSERT INTO `customer_enquiry` (`id`, `post_date`, `modified_date`, `name`, `email`, `contact`, `message`, `ip`) VALUES
(1, '2016-05-12 13:26:08', '0000-00-00 00:00:00', 'test', 'test@yahoo.com', '987698676', 'Thanks', '192.168.1.12'),
(2, '2016-05-12 13:39:22', '0000-00-00 00:00:00', 'Teen', 'teen@gmail.com', '98686', 'Teen Thanks', '192.168.1.12');

-- --------------------------------------------------------

--
-- Table structure for table `get_in_touch`
--

CREATE TABLE IF NOT EXISTS `get_in_touch` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `enquiry` text NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `get_in_touch`
--

INSERT INTO `get_in_touch` (`id`, `post_date`, `modified_date`, `name`, `contact`, `email`, `subject`, `enquiry`, `ip`) VALUES
(1, '2016-05-10 10:30:43', '0000-00-00 00:00:00', 'Neelmani', '02298565656', 'neel@gmail.com', 'test', 'test', '192.168.1.121'),
(2, '2016-05-10 10:33:06', '0000-00-00 00:00:00', 'Sultan', '0252666', 'sultan@gmail.comm', 'test', 'tt', '192.168.1.121'),
(3, '2016-05-10 10:36:14', '0000-00-00 00:00:00', 'shubham', '26626', 'shub@gmail.com', 'test', 'test', '192.168.1.121'),
(4, '2016-05-10 10:37:04', '0000-00-00 00:00:00', 'nain', '02151', 'nana@yahoo.com', 'testststs', 'tdttss', '192.168.1.121');

-- --------------------------------------------------------

--
-- Table structure for table `home_shopnow_image`
--

CREATE TABLE IF NOT EXISTS `home_shopnow_image` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `home_shopnow_image`
--

INSERT INTO `home_shopnow_image` (`id`, `post_date`, `modified_date`, `title`, `image`, `url`, `status`) VALUES
(1, '2016-04-30 13:14:53', '2016-05-05 16:09:33', 'Sparkling Diamonds', '53898banner_a1.jpg', 'test1.php', '1'),
(2, '2016-04-30 13:16:04', '2016-05-05 16:10:02', 'Valentine Collection', '56993banner_a2.jpg', 'test2.php', '1'),
(3, '2016-04-30 13:17:03', '2016-05-05 16:10:17', 'Stunner', '65199banner_a3.jpg', 'test3.php', '1'),
(4, '2016-04-30 13:17:47', '2016-05-05 16:10:27', 'Every Festive', '13801banner_a4.jpg', 'test4.php', '1'),
(5, '2016-04-30 13:18:27', '2016-05-05 16:10:40', 'Floral Divine', '26803banner_a5.jpg', 'test5.php', '1'),
(6, '2016-04-30 13:19:14', '2016-05-05 16:10:53', 'Special Bounds', '87060banner_a6.jpg', 'test6.php', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `pid` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `cat_id` int(255) NOT NULL,
  `sub_catid` int(255) NOT NULL,
  `sub_sub_catid` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `product_code` varchar(250) NOT NULL,
  `product_flag` varchar(250) NOT NULL,
  `product_price` int(55) NOT NULL,
  `priority` int(55) NOT NULL,
  `body` text NOT NULL,
  `img1` varchar(255) NOT NULL,
  `img2` varchar(250) NOT NULL,
  `img3` varchar(250) NOT NULL,
  `img4` varchar(250) NOT NULL,
  `list_products` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `post_date`, `modified_date`, `cat_id`, `sub_catid`, `sub_sub_catid`, `title`, `product_code`, `product_flag`, `product_price`, `priority`, `body`, `img1`, `img2`, `img3`, `img4`, `list_products`, `status`) VALUES
(1, '2016-05-06 13:42:46', '2016-05-14 12:56:03', 1, 1, 1, 'NEW RING', 'RING120', 'TMK,Best Buy', 9000, 0, '<ul>\r\n	<li>An elegant 21 diamonds studded promise band</li>\r\n	<li>18kt yellow gold.</li>\r\n	<li>HI-VS Diamond Quality with 0.25 Carat Diamond weight</li>\r\n</ul>', '50669zoom_2.jpg', '16986zoom_3.jpg', '54489zoom_4.jpg', '894281462434518images_(2).jpg', '9,11', '1'),
(2, '2016-05-06 14:13:59', '0000-00-00 00:00:00', 4, 15, 0, 'LAXMI 2GMS GOLD COIN', 'CO12', 'TMK', 95000, 0, '<p>Gold Coins</p>', '144991462434518images_(2).jpg', '680711462434585images_(1).jpg', '', '', '', '1'),
(3, '2016-05-06 14:46:02', '0000-00-00 00:00:00', 4, 15, 0, 'LORD KRISHNA COIN 10GMS', 'CO2', 'Best Buy', 12000, 0, '<p><span style="font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px">LORD KRISHNA COIN 10GMS</span></p>', '979731462434585images_(1).jpg', '723361462434518images_(2).jpg', '', '', '', '1'),
(4, '2016-05-06 15:20:42', '2016-05-13 15:11:58', 1, 1, 3, 'NEW COCKTAIL RINGS', 'COCK25', 'New', 9800, 0, '<p>New Cocktail Rings</p>', '46798zoom_7.jpg', '17917zoom_6.jpg', '', '', '9', '0'),
(5, '2016-05-06 15:25:55', '2016-05-13 15:52:25', 1, 1, 12, 'MENS RING', 'RA58', 'New', 7500, 0, '<p>Mens Ring</p>', '49980zoom_6.jpg', '', '80029zoom03.jpg', '', '12,15,18', '1'),
(6, '2016-05-06 15:28:27', '0000-00-00 00:00:00', 3, 12, 0, 'VALENTINE RING', 'VAL445', 'Best Buy', 74552, 0, '<p>Valentine Ring</p>', '68408zoom_3.jpg', '', '', '', '', '1'),
(7, '2016-05-06 15:30:05', '0000-00-00 00:00:00', 3, 12, 0, 'TRENDING RING', 'TR56', 'TMK', 12000, 0, '<p>TRENDING RING</p>', '71495zoom_4.jpg', '20911zoom_5.jpg', '', '', '', '1'),
(8, '2016-05-06 15:32:52', '2016-05-09 15:46:47', 5, 18, 0, 'STUNNED EARRINGS', 'STU34', 'TMK', 8000, 0, '<p>STUNNED EARRINGS</p>', '94192tt.jpg', '63400zoom_3.jpg', '', '', '', '1'),
(9, '2016-05-06 15:36:39', '2016-05-13 14:30:36', 2, 10, 0, 'NEW DIAMOND RING', 'RR58', 'TMK', 9000, 0, '<p>New Diamond Ring</p>', '153501.jpg', '136932.jpg', '', '', '', '1'),
(10, '2016-05-06 15:37:47', '0000-00-00 00:00:00', 2, 10, 0, 'STUNNING EARINGS', 'STU45', 'TMK', 5000, 0, '<p>Stunning Earings</p>', '186735.jpg', '', '634033.jpg', '', '', '1'),
(11, '2016-05-09 12:07:10', '2016-05-13 14:59:26', 1, 1, 4, 'NEW BANDS', 'BAND48', 'Best Buy,New', 89000, 0, '<p>New bands</p>', '31111zoom_5.jpg', '84380zoom_7.jpg', '', '', '1,2,10,12,16', '1'),
(12, '2016-05-13 14:32:52', '0000-00-00 00:00:00', 2, 10, 0, 'SILVER RING', 'ED34', 'TMK', 4500, 0, '<p>New Product Silver Ring</p>', '28241zoom_5.jpg', '', '', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products_old`
--

CREATE TABLE IF NOT EXISTS `products_old` (
  `pid` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `cid` int(255) NOT NULL,
  `product_code` varchar(250) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(250) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `products_old`
--

INSERT INTO `products_old` (`pid`, `post_date`, `modified_date`, `cid`, `product_code`, `title`, `body`, `image`, `url`, `status`) VALUES
(1, '2016-04-25 11:20:10', '2016-04-26 15:30:25', 4, 'GO121', 'GOLD CHAIN', '<p>Gold Plated Chain</p>', '1461563410TDP-2416.jpg', '', '1'),
(2, '2016-04-25 11:20:57', '2016-04-26 15:30:46', 1, 'RING34', 'DIAMOND RINGS', '<p>Diamond Rings Very Affordable Rates</p>', '14616628941.jpg*14616628943.jpg', '', '1'),
(3, '2016-04-25 11:21:53', '2016-04-27 11:29:30', 2, 'RING45', 'WOMENS RINGS', '<p>Womens Golden Rings</p>', '14617367703.jpg', '', '1'),
(4, '2016-04-25 11:22:43', '2016-04-26 15:31:26', 4, 'CHAIN34', 'MANGALSUTRA', '<p>Gold 24 Carret Platinum Mangalsutra</p>', '1461563563R-14990-001HL.jpg*1461563563SRIN-22.jpg', '', '1'),
(5, '2016-04-26 14:09:24', '2016-04-26 15:22:52', 2, 'ROS52', 'THE ROSALIC RING', '<p>The Rosalic Ring</p>\r\n\r\n<p><span style="color:rgb(99, 99, 99); font-family:crimson text,serif; font-size:16px">Diamond And Ruby Ring In 18KT Yellow Gold (2.42 gms) with Diamonds (0.2320 Ct)</span></p>', '14616628492.jpg*14616628494.jpg', '', '1'),
(6, '2016-04-26 15:19:02', '2016-04-27 12:00:40', 2, 'RING89', 'ENGAGEMENT RINGS', '<p>Engagement Rings&nbsp;Engagement Rings</p>', '14617386401.jpg*14617386402.jpg*14617386403.jpg*14617386404.jpg', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `product_enquiry`
--

CREATE TABLE IF NOT EXISTS `product_enquiry` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `product_enquiry`
--

INSERT INTO `product_enquiry` (`id`, `post_date`, `modified_date`, `product_name`, `product_code`, `customer_name`, `email`, `contact_no`, `message`) VALUES
(1, '2016-05-04 10:59:22', '0000-00-00 00:00:00', 'BRIDAL NEW DIAMOND RING', 'BRI845', 'Susan', 'susan@gmail.com', '9856231025', 'For Diamonds'),
(2, '2016-05-04 15:21:43', '0000-00-00 00:00:00', 'DAILY USE PENDANTS', 'DD89', 'hanuman', 'hanum@gmail.com', '8887', 'Thanks'),
(3, '2016-05-04 16:43:17', '0000-00-00 00:00:00', 'DIAMOND RING', 'CO89', 'rrrat', 'rra@yahoo.com', '6663263', 'Thanks'),
(4, '2016-05-06 15:07:00', '0000-00-00 00:00:00', 'LORD KRISHNA COIN 10GMS', 'CO2', 'yery', 'kalpeshk9967016292@gmail.com', '09987555381', 'yry'),
(5, '2016-05-06 15:21:24', '0000-00-00 00:00:00', 'NEW COCKTAIL RINGS', 'COCK25', 'tt', 't@gmail.com', '879887', 'thnaks');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `cat_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `video` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `post_date`, `modified_date`, `cat_id`, `name`, `video`, `image`, `status`) VALUES
(1, '2016-04-27 16:00:27', '2016-05-13 14:31:12', 1, 'RINGS', '<iframe src="https://www.youtube.com/embed/VrTQ9UgyoEY?autoplay=0&loop=1&playlist=VrTQ9UgyoEY&controls=1&showinfo=0;rel=0" frameborder="0" allowtransparency="true" allowfullscreen></iframe>', '', '1'),
(2, '2016-04-27 16:01:03', '2016-05-04 13:25:26', 1, 'PENDANTS SETS', '<iframe width="560" height="315" src="https://www.youtube.com/embed/sqXN83LzuUU" frameborder="0" allowfullscreen></iframe>', '', '1'),
(3, '2016-04-28 11:10:39', '2016-05-04 13:13:39', 1, 'NECKLACES SETS', '<iframe width="560" height="315" src="https://www.youtube.com/embed/IRzmHcFCHfk" frameborder="0" allowfullscreen></iframe>', '25357nav_bg.png', '1'),
(4, '2016-04-28 11:11:00', '0000-00-00 00:00:00', 1, 'TANMANIYA', '', '', '1'),
(5, '2016-04-28 11:11:49', '0000-00-00 00:00:00', 1, 'BANGLES & BRACELETS', '', '', '1'),
(6, '2016-04-28 11:12:09', '0000-00-00 00:00:00', 1, 'EARRING', '', '', '1'),
(7, '2016-04-28 11:14:37', '0000-00-00 00:00:00', 1, 'PENDANTS & CHAINS', '', '', '1'),
(8, '2016-04-28 11:14:53', '2016-05-16 12:20:37', 1, 'NOSEPINS', '', '', '1'),
(9, '2016-04-30 11:58:23', '2016-05-13 14:31:32', 2, 'CATEGORY 1', '<iframe src="https://www.youtube.com/embed/VrTQ9UgyoEY?autoplay=0&loop=1&playlist=VrTQ9UgyoEY&controls=1&showinfo=0;rel=0" frameborder="0" allowtransparency="true" allowfullscreen></iframe>', '27582p1.jpg', '1'),
(10, '2016-05-02 11:11:39', '0000-00-00 00:00:00', 2, 'CATEGORY 2', '', '292281.jpg', '1'),
(11, '2016-05-02 11:21:41', '0000-00-00 00:00:00', 2, 'CATEGORY 3', 'www.youtube.com', '782251.jpg', '1'),
(12, '2016-05-04 18:53:38', '0000-00-00 00:00:00', 3, 'RINGS', '', '915393.jpg', '1'),
(13, '2016-05-04 18:54:22', '0000-00-00 00:00:00', 3, 'EARINGS', '', '432013.jpg', '1'),
(14, '2016-05-04 18:54:39', '0000-00-00 00:00:00', 3, 'PENDANTS', '', '138155.jpg', '1'),
(15, '2016-05-05 10:57:37', '2016-05-05 11:10:47', 4, 'GOLD', '', '379364.jpg', '1'),
(16, '2016-05-05 10:59:15', '2016-05-05 11:11:00', 4, 'SILVER', '', '593725.jpg', '1'),
(17, '2016-05-05 11:02:59', '0000-00-00 00:00:00', 5, 'PEARLS & PETALS', '', '953453.jpg', '1'),
(18, '2016-05-05 11:04:32', '2016-05-06 12:19:41', 5, 'PENDANTS', '', '418375.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe_newsletter`
--

CREATE TABLE IF NOT EXISTS `subscribe_newsletter` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subscribe_newsletter`
--

INSERT INTO `subscribe_newsletter` (`id`, `post_date`, `email`, `ip`) VALUES
(1, '2016-05-10 13:34:50', 'test@gmail.com', '192.168.1.121'),
(3, '2016-05-10 14:26:55', 'shakti@gmail.com', '192.168.1.121'),
(4, '2016-05-10 14:32:03', 'mithun@gmail.con', '192.168.1.121'),
(5, '2016-05-10 14:32:48', 'sunil@yahoo.com.in', '192.168.1.121'),
(6, '2016-05-10 14:46:01', 'shan@yahoo.com', '192.168.1.121');

-- --------------------------------------------------------

--
-- Table structure for table `sub_subcategory`
--

CREATE TABLE IF NOT EXISTS `sub_subcategory` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL,
  `cat_id` int(255) NOT NULL,
  `sub_cat_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `background_image` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `sub_subcategory`
--

INSERT INTO `sub_subcategory` (`id`, `post_date`, `modified_date`, `cat_id`, `sub_cat_id`, `name`, `image`, `background_image`, `status`) VALUES
(1, '2016-04-27 16:59:27', '2016-05-13 14:44:25', 1, 1, 'DAILY RINGS', '75398ring_1.jpg', '', '1'),
(34, '2016-05-02 12:42:05', '0000-00-00 00:00:00', 1, 7, 'PENDENT 2', '646782.jpg', '', '1'),
(3, '2016-04-27 17:31:18', '2016-05-04 16:59:58', 1, 1, 'COCKTAIL RING', '97767ring_2.jpg', '', '1'),
(4, '2016-04-28 11:19:06', '2016-05-02 11:29:36', 1, 1, 'BANDS', '22086ring_3.jpg', '', '1'),
(33, '2016-05-02 12:41:39', '0000-00-00 00:00:00', 1, 7, 'PENDENT 1', '488331.jpg', '', '1'),
(6, '2016-04-28 17:26:11', '2016-05-16 12:21:04', 1, 8, 'NOSEPIN 1', '21709nose1.jpg', '', '0'),
(7, '2016-05-02 12:06:48', '2016-05-02 12:07:17', 1, 1, 'COUPLE BANDS', '98090ring_5.jpg', '', '1'),
(8, '2016-05-02 12:08:20', '0000-00-00 00:00:00', 1, 1, 'FASHION RINGS', '94609ring_6.jpg', '', '1'),
(9, '2016-05-02 12:08:54', '0000-00-00 00:00:00', 1, 1, 'SOLITAIRES', '94580ring_7.jpg', '', '1'),
(10, '2016-05-02 12:12:15', '0000-00-00 00:00:00', 1, 1, 'ENGAGEMENT RINGS', '28827ring_8.jpg', '', '1'),
(11, '2016-05-02 12:12:55', '0000-00-00 00:00:00', 1, 1, 'BRIDAL RINGS', '93749ring_9.jpg', '', '1'),
(12, '2016-05-02 12:13:32', '2016-05-02 12:17:55', 1, 1, 'MENS RINGS', '92876ring_4.jpg', '', '1'),
(13, '2016-05-02 12:18:51', '2016-05-14 10:53:14', 1, 1, 'ALL RINGS', '74460ring_10.jpg', '', '0'),
(14, '2016-05-02 12:26:41', '0000-00-00 00:00:00', 1, 2, 'PENDENT 1', '219641.jpg', '', '1'),
(15, '2016-05-02 12:27:40', '2016-05-02 12:31:08', 1, 2, 'PENDENT 2', '130372.jpg', '', '1'),
(16, '2016-05-02 12:29:16', '2016-05-02 12:30:20', 1, 2, 'PENDENT 3', '706273.jpg', '', '1'),
(17, '2016-05-02 12:29:33', '2016-05-02 12:31:23', 1, 2, 'PENDENT 4', '151824.jpg', '', '1'),
(18, '2016-05-02 12:29:51', '2016-05-02 12:30:00', 1, 2, 'PENDENT 5', '148055.jpg', '', '1'),
(19, '2016-05-02 12:32:30', '0000-00-00 00:00:00', 1, 3, 'NECKLACES 1', '452771.jpg', 'nav_bg.png', '1'),
(20, '2016-05-02 12:32:45', '0000-00-00 00:00:00', 1, 3, 'NECKLACES 2', '423172.jpg', 'nav_bg.png', '1'),
(21, '2016-05-02 12:33:36', '2016-05-16 12:31:56', 1, 4, 'TANMANIYA 1', '905621.jpg', '', '0'),
(22, '2016-05-02 12:33:52', '2016-05-16 12:32:02', 1, 4, 'TANMANIYA 2', '812012.jpg', '', '0'),
(23, '2016-05-02 12:34:38', '0000-00-00 00:00:00', 1, 5, 'BANGLES 1', '427481.jpg', '', '1'),
(24, '2016-05-02 12:34:54', '0000-00-00 00:00:00', 1, 5, 'BANGLES 2', '389642.jpg', '', '1'),
(25, '2016-05-02 12:35:26', '0000-00-00 00:00:00', 1, 5, 'BANGLES 3', '639893.jpg', '', '1'),
(26, '2016-05-02 12:35:41', '0000-00-00 00:00:00', 1, 5, 'BANGLES 4', '791504.jpg', '', '1'),
(27, '2016-05-02 12:35:56', '2016-05-02 12:36:04', 1, 5, 'BANGLES 5', '247695.jpg', '', '1'),
(28, '2016-05-02 12:36:40', '0000-00-00 00:00:00', 1, 6, 'EARRINGS 1', '150191.jpg', '', '1'),
(29, '2016-05-02 12:37:02', '0000-00-00 00:00:00', 1, 6, 'EARRINGS 2', '359532.jpg', '', '1'),
(30, '2016-05-02 12:37:42', '0000-00-00 00:00:00', 1, 6, 'EARRINGS 3', '552273.jpg', '', '1'),
(31, '2016-05-02 12:37:58', '0000-00-00 00:00:00', 1, 6, 'EARRINGS 4', '768774.jpg', '', '1'),
(32, '2016-05-02 12:38:14', '0000-00-00 00:00:00', 1, 6, 'EARRINGS 5', '742105.jpg', '', '1'),
(35, '2016-05-02 12:42:19', '0000-00-00 00:00:00', 1, 7, 'PENDENT 3', '459203.jpg', '', '1'),
(36, '2016-05-02 12:42:38', '0000-00-00 00:00:00', 1, 7, 'PENDENT 4', '610054.jpg', '', '1'),
(37, '2016-05-02 12:42:54', '0000-00-00 00:00:00', 1, 7, 'PENDENT 5', '816785.jpg', '', '1'),
(38, '2016-05-02 12:44:17', '2016-05-16 12:21:16', 1, 8, 'NOSEPIN 2', '281222.jpg', '', '0'),
(39, '2016-05-02 12:44:17', '2016-05-16 12:21:23', 1, 8, 'NOSEPIN 2', '668722.jpg', '', '0'),
(40, '2016-05-02 12:44:52', '2016-05-16 12:21:29', 1, 8, 'NOSEPIN 3', '170703.jpg', '', '0'),
(41, '2016-05-02 12:45:34', '2016-05-16 12:21:36', 1, 8, 'NOSEPIN 4', '539334.jpg', '', '0');
